SCENEMATE WEBSITE PACKAGE

Files: index.html, style.css, script.js

1. Supabase URL and publishable key are already in script.js.
2. Do NOT replace the publishable key with a service_role/secret key.
3. Supabase Auth: enable Email provider.
4. URL Configuration: set Site URL and Redirect URL to the real address where you host SceneMate. For local testing, use your local server URL.
5. Profiles table expected columns: id (uuid), name, bio, profile_picture_url, acting_experience, created_at, updated_at.
6. Storage bucket expected: profile-pictures.
7. Camera access requires HTTPS on a hosted site (localhost is also normally allowed).
8. If email confirmation is enabled, the confirmation link must point to a URL listed under Authentication > URL Configuration.
